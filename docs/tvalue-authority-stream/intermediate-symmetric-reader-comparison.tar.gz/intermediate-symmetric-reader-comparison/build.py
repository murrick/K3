from pathlib import Path
import json,hashlib,subprocess
p=Path(__file__).parent;parent='148910a3707e81332ab3ab9e8f811423368cd492'
prior=json.loads(Path('docs/tvalue-layer-cost/build-validation.json').read_text());native=Path('../build/tvalue-layer-cost');assert all(hashlib.sha256((native/k).read_bytes()).hexdigest()==v for k,v in prior['class_sha256'].items())
c=json.loads((p/'changes.json').read_text());original=Path(c['journal_original']).read_text();control=(p/'BeforeAuthorityJournal.java').read_text().replace('BeforeAuthorityJournal','IdleProjectionJournal')
for old,new in reversed(c['control_journal_replacements']):assert control.count(new)==1;control=control.replace(new,old,1)
assert control==original
assert (p/'BeforeAuthorityRead.java').read_text().replace('BeforeAuthorityRead','ResidentTValueRead')==Path(c['reader_original']).read_text()
recovered=(p/'StreamAuthorityJournal.java').read_text().replace('StreamAuthorityJournal','IdleProjectionJournal')
for old,new in reversed(c['journal_replacements']):assert recovered.count(new)==1;recovered=recovered.replace(new,old,1)
assert recovered==original
recovered=(p/'StreamAuthorityRead.java').read_text().replace('StreamAuthorityRead','ResidentTValueRead')
for old,new in reversed(c['reader_replacements']):assert recovered.count(new)==1;recovered=recovered.replace(new,old,1)
assert recovered==Path(c['reader_original']).read_text()
runner=(p/'AuthorityCostRunner.java').read_text().replace('AuthorityCostRunner','IdleCostRunner').replace('BeforeAuthorityJournal','BeforeIdleJournal').replace('StreamAuthorityJournal','IdleProjectionJournal');assert runner==Path('docs/tvalue-idle-projection/IdleCostRunner.java').read_text()
scope=(p/'AuthorityScopeRunner.java').read_text().replace((p/'scope-addition.java.txt').read_text(),'').replace('  authorityControls();maps();User user=','  maps();User user=').replace('AuthorityScopeRunner','IdleScopeRunner').replace('BeforeAuthorityJournal','BeforeIdleJournal').replace('StreamAuthorityJournal','IdleProjectionJournal');assert scope==Path('docs/tvalue-idle-projection/IdleScopeRunner.java').read_text()
out=Path('../build/tvalue-authority-stream');out.mkdir(parents=True,exist_ok=True);sources=[p/(x+'.java') for x in ('BeforeAuthorityJournal','StreamAuthorityJournal','StreamAuthorityRead','BeforeAuthorityRead','AuthorityCostRunner','AuthorityScopeRunner')]
cmd=['java','-jar','../tooling/ecj.jar','-1.8','-nowarn','-cp',str(native)+':lib/jline-3.13.0.jar','-d',str(out),*map(str,sources)];subprocess.run(cmd,check=True)
info={'parent':parent,'command':cmd,'prior_runtime_class_hashes_verified':len(prior['class_sha256']),'prior_journal_source_recovered':True,'reader_source_recovered_except_declared_serialization_edits':True,'runner_recovered_by_class_rename_only':True,'control_reader_source_recovered_by_class_rename_only':True,'control_oracle_route_change_only':True,'scope_source_recovered_except_declared_extra_controls':True,'full_oracle_fresh_and_independent_in_both':True,'class_sha256':{str(q.relative_to(out)):hashlib.sha256(q.read_bytes()).hexdigest() for q in out.rglob('*.class')},'source_sha256':{str(q):hashlib.sha256(q.read_bytes()).hexdigest() for q in sources},'native_clean_runtime':'tvalue-layer-cost','native_setter_metadata_bridge':'explicit after native setter returns; no instrumented native class or engine hooks'};(p/'build-validation.json').write_text(json.dumps(info,indent=2)+'\n');print('AUTHORITY_STREAM_BUILD_OK')
